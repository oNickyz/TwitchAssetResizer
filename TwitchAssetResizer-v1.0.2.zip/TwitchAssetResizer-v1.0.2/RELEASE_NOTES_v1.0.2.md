# Twitch Asset Resizer v1.0.2

## Fixes and diagnostics

- Replaced the self-extracting batch launcher with a simple launcher that runs the adjacent PowerShell script, avoiding marker-extraction errors.
- Fixed a Windows PowerShell parameter-set error by replacing `Split-Path -LiteralPath ... -Parent` with `[IO.Path]::GetDirectoryName()`.
- Hardened input-path trimming and output-folder creation.
- Added stage, line, command, and stack-trace details to error messages so any remaining Windows-specific failures can be diagnosed accurately.
- The `.bat` and `.ps1` files must stay together in the same folder.

## Upgrade

Download and extract the complete ZIP package, then drag a PNG onto `TwitchAssetResizer.bat`. ImageMagick remains optional.
